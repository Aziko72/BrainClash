import base64
import json
from typing import Dict, Any

# --- Payme, Click va Rahmat Konfiguratsiyasi ---
PAYME_MERCHANT_ID = "YOUR_PAYME_MERCHANT_ID"
CLICK_MERCHANT_ID = "YOUR_CLICK_MERCHANT_ID"
CLICK_SERVICE_ID = "YOUR_CLICK_SERVICE_ID"
CLICK_SECRET_KEY = "YOUR_CLICK_SECRET_KEY"
RAHMAT_MERCHANT_SLUG = "YOUR_RAHMAT_SLUG" # Rahmat.me yoki Rahmat.uz dagi profilingiz/hab nomi

def generate_rahmat_link(amount_uzs: int, order_id: str, slug: str = RAHMAT_MERCHANT_SLUG) -> str:
    """
    Rahmat to'lov va donat platformasi havolasini generatsiya qilish.
    Uzcard, Humo, Visa, Mastercard va Apple Pay orqali tezkor to'lov.
    """
    return f"https://rahmat.me/{slug}?amount={amount_uzs}&comment={order_id}"

def generate_payme_link(amount_uzs: int, order_id: str) -> str:
    amount_tiyin = amount_uzs * 100
    params = f"m={PAYME_MERCHANT_ID};ac.order_id={order_id};a={amount_tiyin}"
    encoded_params = base64.b64encode(params.encode("utf-8")).decode("utf-8")
    return f"https://checkout.paycom.uz/{encoded_params}"

def generate_click_link(amount_uzs: int, order_id: str, return_url: str = "quizduel://payment-success") -> str:
    return (
        f"https://my.click.uz/services/pay"
        f"?service_id={CLICK_SERVICE_ID}"
        f"&merchant_id={CLICK_MERCHANT_ID}"
        f"&amount={amount_uzs}"
        f"&transaction_param={order_id}"
        f"&return_url={return_url}"
    )

def handle_rahmat_webhook(data: Dict[str, Any], db_conn) -> Dict[str, Any]:
    """
    Rahmat platformasidan to'lov muvaffaqiyatli o'tganda keladigan Webhook.
    """
    order_id = data.get("comment") or data.get("order_id")
    amount = data.get("amount")
    status = data.get("status")

    if status == "success" or status == "PAID":
        # Foydalanuvchiga mahsulotni faollashtirish
        return {"success": True, "order_id": order_id}
    return {"success": False}

def handle_payme_webhook(data: Dict[str, Any], db_conn) -> Dict[str, Any]:
    method = data.get("method")
    params = data.get("params", {})
    req_id = data.get("id")

    if method == "CheckPerformTransaction":
        return {"result": {"allow": True}, "id": req_id}
    elif method == "CreateTransaction":
        return {
            "result": {
                "create_time": 1700000000000,
                "transaction": "payme_txn_" + str(params.get("id", "1")),
                "state": 1,
                "receivers": None
            },
            "id": req_id
        }
    elif method == "PerformTransaction":
        return {
            "result": {
                "transaction": "payme_txn_" + str(params.get("id", "1")),
                "perform_time": 1700000000000,
                "state": 2
            },
            "id": req_id
        }
    return {"error": {"code": -32601, "message": "Method not found"}, "id": req_id}

def handle_click_webhook(data: Dict[str, Any], db_conn) -> Dict[str, Any]:
    action = data.get("action")
    click_trans_id = data.get("click_trans_id")
    merchant_trans_id = data.get("merchant_trans_id")

    if action in [0, "0"]:
        return {
            "click_trans_id": click_trans_id,
            "merchant_trans_id": merchant_trans_id,
            "merchant_prepare_id": "prep_" + str(click_trans_id),
            "error": 0,
            "error_note": "Success"
        }
    elif action in [1, "1"]:
        return {
            "click_trans_id": click_trans_id,
            "merchant_trans_id": merchant_trans_id,
            "merchant_confirm_id": "conf_" + str(click_trans_id),
            "error": 0,
            "error_note": "Success"
        }
    return {"error": -1, "error_note": "Action unknown"}
