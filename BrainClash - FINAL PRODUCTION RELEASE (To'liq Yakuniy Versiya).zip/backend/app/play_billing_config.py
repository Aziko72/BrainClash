"""
Google Play Console In-App Purchases & Subscriptions Matrix for BrainClash
"""

GOOGLE_PLAY_PRODUCTS = [
    {
        "product_id": "vip_pass_monthly",
        "type": "SUBSCRIPTION",
        "title": "VIP Pass (1 Month)",
        "description": "100% Ad-Free, 2x Coins & XP, 20 Lives, Golden Profile Badge",
        "pricing": {
            "GLOBAL_USD": 2.99,
            "UZ_UZS": 29990,
            "RU_RUB": 279,
            "KZ_KZT": 1490
        }
    },
    {
        "product_id": "coins_500",
        "type": "CONSUMABLE",
        "title": "500 Coins Pack",
        "pricing": {
            "GLOBAL_USD": 0.49,
            "UZ_UZS": 4990
        }
    },
    {
        "product_id": "coins_2500",
        "type": "CONSUMABLE",
        "title": "2,500 Coins (+20% Bonus)",
        "pricing": {
            "GLOBAL_USD": 1.49,
            "UZ_UZS": 14990
        }
    },
    {
        "product_id": "coins_10000",
        "type": "CONSUMABLE",
        "title": "10,000 Coins (Mega Chest)",
        "pricing": {
            "GLOBAL_USD": 4.99,
            "UZ_UZS": 49990
        }
    },
    {
        "product_id": "energy_full",
        "type": "CONSUMABLE",
        "title": "Instant Full Energy (10 Lives)",
        "pricing": {
            "GLOBAL_USD": 0.29,
            "UZ_UZS": 2990
        }
    }
]
