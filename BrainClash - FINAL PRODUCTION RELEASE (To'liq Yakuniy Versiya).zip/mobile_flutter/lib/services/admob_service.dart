// Google AdMob Real Production Configuration for BrainClash
class AdMobService {
  // App ID
  static const String appId = "ca-app-pub-8868851992788408~1283073296";

  // Rewarded Video Ad Unit ID (+1 Jon / 50/50 Booster)
  static const String rewardedAdUnitId = "ca-app-pub-8868851992788408/9237429404";

  // Test Ad Unit ID for debug testing
  static const String testRewardedAdUnitId = "ca-app-pub-3940256099942544/5224354917";
}
