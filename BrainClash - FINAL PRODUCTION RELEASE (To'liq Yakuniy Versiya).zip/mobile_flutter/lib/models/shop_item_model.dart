class ShopItemModel {
  final int id;
  final String productId; // Google Play Product ID
  final String title;
  final String description;
  final String itemType;
  final int priceUzs;
  final double priceUsd;
  final int coinPrice;
  final int value;
  final String icon;
  final bool isPopular;

  ShopItemModel({
    required this.id,
    required this.productId,
    required this.title,
    required this.description,
    required this.itemType,
    required this.priceUzs,
    required this.priceUsd,
    required this.coinPrice,
    required this.value,
    required this.icon,
    required this.isPopular,
  });

  String getFormattedPrice(String currency) {
    if (currency == 'USD' || currency == 'en') {
      return "\$$priceUsd";
    }
    return "${priceUzs.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]} ')} UZS";
  }
}
